import ncheader from './ncheader'

ncheader.install = function (Vue) {
  Vue.component(ncheader.name, ncheader)
}

export default ncheader
