import VueTinymce from './vue-tinymce'

VueTinymce.install = function (Vue) {
  Vue.component('vue-tinymce', VueTinymce)
}

export default VueTinymce
