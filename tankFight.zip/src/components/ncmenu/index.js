import ncmenu from './ncmenu'

ncmenu.install = function (Vue) {
  Vue.component(ncmenu.name, ncmenu)
}

export default ncmenu
