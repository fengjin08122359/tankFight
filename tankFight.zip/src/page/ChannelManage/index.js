import ChannelManage from './ChannelManage'

ChannelManage.install = function (Vue) {
  Vue.component(ChannelManage.name, ChannelManage)
}

export default ChannelManage
