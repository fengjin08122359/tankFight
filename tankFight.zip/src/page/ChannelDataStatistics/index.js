import ChannelDataStatistics from './ChannelDataStatistics'

ChannelDataStatistics.install = function (Vue) {
  Vue.component(ChannelDataStatistics.name, ChannelDataStatistics)
}

export default ChannelDataStatistics
