import H5Appearance from './H5Appearance'

H5Appearance.install = function (Vue) {
  Vue.component(H5Appearance.name, H5Appearance)
}

export default H5Appearance
