<template>
  <div class="Welcome">
  {{ msg }}
  </div>
</template>

<script>
export default {
  name: 'Welcome',
  data () {
    return {
      msg: 'Welcome'
    }
  }
}
</script>
