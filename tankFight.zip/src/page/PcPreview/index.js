import PcPreview from './PcPreview'

PcPreview.install = function (Vue) {
  Vue.component(PcPreview.name, PcPreview)
}

export default PcPreview
