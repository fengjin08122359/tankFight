<template>
  <div class="h5Preview">
    {{ msg }}
  </div>
</template>

<script>
export default {
  name: 'H5Preview',
  data () {
    return {
      msg: 'H5Preview'
    }
  }
}
</script>
