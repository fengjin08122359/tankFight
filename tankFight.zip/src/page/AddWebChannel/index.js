import AddWebChannel from './AddWebChannel'

AddWebChannel.install = function (Vue) {
  Vue.component(AddWebChannel.name, AddWebChannel)
}

export default AddWebChannel
