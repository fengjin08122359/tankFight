export default {
  0: 'blank',
  1: 'wood',
  2: 'iron',
  3: 'water',
  4: 'home'
}
