import backgroundType from './backgroundType'
import bulletType from './bulletType'
import tankType from './tankType'
import direction from './direction'

export default {
  backgroundType,
  bulletType,
  tankType,
  direction
}
