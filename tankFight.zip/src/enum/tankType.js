export default {
  0: 'blank',
  1: 'tank',
  2: 'opponentTank'
}
