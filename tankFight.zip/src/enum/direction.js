export default {
  0: 'left',
  1: 'top',
  2: 'right',
  3: 'bottom'
}
