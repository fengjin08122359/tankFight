export default {
  0: 'blank',
  1: 'bullet',
  2: 'double',
  3: 'breakStone'
}
